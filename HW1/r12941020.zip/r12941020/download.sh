#!bin/bash
mkdir data
mkdir model_PS
mkdir model_QA

gdown -O data/context.json 12I29gXxPLT825KidfC8L6wgWfCRA2HRi
gdown -O data/test.json 1OwDEyQ6mC_olSABRI5L9YKuND7gBBS60
gdown -O data/valid.json 1nir4V8q3jwuJHUI5-QBa9uHa-Bty6kHn
gdown -O model_PS/model_PS.zip 1ezxpvyTcLz-XnRRVHUUZNEokZ8EQm4Cw
gdown -O model_QA/model_QA.zip 1qdx6mN10zmP7I_RdPgi9WVKatYxN17-4

unzip model_PS/model_PS.zip -d model_PS
unzip model_QA/model_QA.zip -d model_QA