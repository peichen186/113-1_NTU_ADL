import argparse
import json
import torch
from tqdm import tqdm
from datasets import load_dataset
from itertools import chain
from torch.utils.data import DataLoader
from transformers import (
    AutoConfig,
    AutoModelForMultipleChoice,
    AutoTokenizer,
    default_data_collator,
)
from dataclasses import dataclass
from typing import Optional, Union
from transformers.utils import PaddingStrategy
from transformers import PreTrainedTokenizerBase


# Custom Data Collator for Multiple Choice tasks
@dataclass
class MCDataCollator:
    tokenizer: PreTrainedTokenizerBase
    padding: Union[bool, str, PaddingStrategy] = True
    max_length: Optional[int] = None
    pad_to_multiple_of: Optional[int] = None

    def __call__(self, features):
    # 檢查是否有 'labels' 欄位，因為推理階段可能沒有該欄位
        label_name = "label" if "label" in features[0].keys() else "labels"
        
        if label_name in features[0]:
            labels = [feature.pop(label_name) for feature in features]
        else:
            labels = None  # 測試資料集沒有標籤

        batch_size = len(features)
        num_choices = len(features[0]["input_ids"])
        flattened_features = [
            [{k: v[i] for k, v in feature.items()} for i in range(num_choices)] for feature in features
        ]
        flattened_features = list(chain(*flattened_features))

        batch = self.tokenizer.pad(
            flattened_features,
            padding=self.padding,
            max_length=self.max_length,
            pad_to_multiple_of=self.pad_to_multiple_of,
            return_tensors="pt",
        )

        # Un-flatten
        batch = {k: v.view(batch_size, num_choices, -1) for k, v in batch.items()}

        # 如果有 labels，則將其加回 batch
        if labels is not None:
            batch["labels"] = torch.tensor(labels, dtype=torch.int64)
        
        return batch



# Argument parsing function
def get_args():
    parser = argparse.ArgumentParser(description="Run inference on a multiple choice task")
    parser.add_argument("--context_file", type=str, help="Path to the context file (json format)")
    parser.add_argument("--test_file", type=str, help="Path to the test data file (json format)")
    parser.add_argument("--output_file", type=str, help="Path to save the inference output (json format)")
    parser.add_argument("--model_path", type=str, help="Path to the pretrained model")
    parser.add_argument("--tokenizer_path", type=str, help="Path to the tokenizer")
    parser.add_argument("--max_seq_len", type=int, default=128, help="Maximum sequence length for tokenization")
    parser.add_argument("--batch_size", type=int, default=8, help="Batch size for inference")
    parser.add_argument("--use_cuda", action="store_true", help="Use CUDA for inference if available")
    return parser.parse_args()


# Main inference function
def run_inference():
    args = get_args()

    # Load datasets
    raw_datasets = load_dataset('json', data_files={'test': args.test_file})
    
    # Load context
    with open(args.context_file, 'r', encoding='utf-8') as f:
        context = json.load(f)

    # Load pretrained model and tokenizer
    config = AutoConfig.from_pretrained(args.model_path)
    tokenizer = AutoTokenizer.from_pretrained(args.tokenizer_path)
    model = AutoModelForMultipleChoice.from_pretrained(args.model_path, config=config)

    # Adjust tokenizer size if necessary
    if len(tokenizer) > model.get_input_embeddings().weight.shape[0]:
        model.resize_token_embeddings(len(tokenizer))

    padding = "max_length"

    # Preprocessing function
    def preprocess_fn(examples):
        questions = [[q] * 4 for q in examples['question']]
        answers = [[context[i] for i in options] for options in examples['paragraphs']]
        labels = [0] * len(examples['question'])

        # Flatten and tokenize
        questions = list(chain(*questions))
        answers = list(chain(*answers))
        tokenized = tokenizer(
            questions,
            answers,
            max_length=args.max_seq_len,
            padding=padding,
            truncation=True,
        )
        return {k: [v[i:i + 4] for i in range(0, len(v), 4)] for k, v in tokenized.items()}

    # Process datasets
    processed_dataset = raw_datasets.map(preprocess_fn, batched=True, remove_columns=raw_datasets['test'].column_names)
    test_dataset = processed_dataset['test']

    # DataLoader setup
    data_collator = MCDataCollator(tokenizer)
    test_loader = DataLoader(test_dataset, batch_size=args.batch_size, collate_fn=data_collator)

    # Set device for model
    device = torch.device('cuda' if args.use_cuda and torch.cuda.is_available() else 'cpu')
    model.to(device)

    # Run inference
    model.eval()
    predictions = torch.zeros(0, dtype=int)
    for batch in tqdm(test_loader):
        batch = {k: v.to(device) for k, v in batch.items()}
        with torch.no_grad():
            outputs = model(**batch)
            pred = outputs.logits.argmax(dim=-1)
        predictions = torch.cat((predictions, pred.cpu()))

    # Load test file and update predictions
    with open(args.test_file, 'r', encoding='utf-8') as f:
        test_data = json.load(f)

    for idx, prediction in enumerate(predictions):
        test_data[idx]['relevant'] = int(test_data[idx]['paragraphs'][int(prediction)])

    # Save output
    with open(args.output_file, 'w', encoding='utf-8') as f:
        json.dump(test_data, f, ensure_ascii=False)
    print(f"Inference completed. Results saved at {args.output_file}")


if __name__ == "__main__":
    run_inference()
