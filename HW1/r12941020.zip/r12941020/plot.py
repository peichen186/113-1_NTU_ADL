import json
import matplotlib.pyplot as plt

# Load EM data
with open('./QA_hfl_chinese_lert_base_2/model/QA_hfl_chinese_lert_base/train_results_EM.json', 'r') as em_file:
    em_data = json.load(em_file)

# Load Loss data
with open('./QA_hfl_chinese_lert_base_2/model/QA_hfl_chinese_lert_base/train_results_loss.json', 'r') as loss_file:
    loss_data = json.load(loss_file)

# Extract EM and loss values
em_values = em_data['EM']
loss_values = loss_data['step_loss']

# Simulating test loss for demonstration as test loss is not provided
# You can update this part based on your test loss data if available.
test_loss_values = [0.6, 0.7, 0.8, 0.85, 0.9, 0.95, 1.0, 1.05, 1.1, 1.15]

# Plot configuration
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

# Plot Loss curve
ax1.plot(loss_values, label='train', color='blue')
#ax1.plot(test_loss_values, label='test', color='orange', marker='x')
ax1.set_title('Loss')
ax1.set_xlabel('Epoch')
ax1.set_ylabel('Loss')
ax1.legend()
ax1.grid(True)

# Plot EM curve
ax2.plot(em_values, label='Exact Match', color='blue')
ax2.set_title('Exact Match')
ax2.set_xlabel('Epoch')
ax2.set_ylabel('Exact Match')
ax2.legend()
ax2.grid(True)

# Show the plot
plt.tight_layout()
plt.show()
