

python PS_infer.py 
  --model_path <model_name_or_path> \
  --tokenizer_path <tokenizer_path> \ 
  --test_file ${2}\
  --context_file ${1} \ 
  --output_file PS_infer_out.json \
  --max_seq_len 512 \
  --batch_size 32 \
  --use_cuda\



python QA_infer.py \
  --model_path <model_name_or_path> \ 
  --tokenizer_path <tokenizer_path> \ 
  --test_file PS_infer_out.json \ 
  --context_file ${1} \ 
  --output_file ${3} \ 
  --max_seq_len 512 \
  --batch_size 32 \
  --use_cuda\
