# ADL-HW1 
光電所 宋姵蓁 R12941020

## Code Reference
 - Paragraph Selection: https://github.com/huggingface/transformers/blob/main/examples/pytorch/multiple-choice/run_swag_no_trainer.py
 - Span Selection: https://github.com/huggingface/transformers/blob/main/examples/pytorch/question-answering/run_qa_no_trainer.py

## Environment Setting
 - Python = 3.10
 - Use `pip install -r requirements.txt` to install packages.

## Steps to run trainning
 - Trainning code are `PS_train.py` and `QA_train.py`.
 - Adjust the hyperparameters.
 - Run
  # Paragraph Selection
    python PS_train.py \
    --model_name_or_path hfl/chinese-lert-base \
    --output_dir <output_dir> \
    --train_file <train_file> \
    --validation_file <validation_file> \
    --context_file <context_file> \
    --cache_dir ./cache/ \
    --per_device_train_batch_size 2\
    --per_device_eval_batch_size 2\
    --gradient_accumulation_steps 4\
    --max_seq_length 512 \
    --learning_rate 3e-5 \
    --num_train_epochs 3 \
    --warmup_ratio 0.1 \
    --best_n_size 20

  # Span Selection
    python QA_train.py \
    --model_name_or_path hfl/chinese-lert-base \
    --output_dir <output_dir> \
    --train_file <train_file> \
    --validation_file <validation_file> \
    --context_file <context_file> \
    --per_device_train_batch_size 2\
    --per_device_eval_batch_size 2\
    --gradient_accumulation_steps 2\
    --max_seq_length 512 \
    --learning_rate 3e-5 \
    --num_train_epochs 3 \
    --warmup_ratio 0.1 \
    --best_n_size 20


## Steps to run inference
 - Inference code are `PS_infer.py` and `QA_infer.py`.
 - Run `bash download.sh` first to download dataset and trained models.
 - Then run `bash run.sh {path_to_context_json} {path_to_test_json} {path_to_output_csv}` and replace the paths.
 - After running `PS_infer.py`, there will be a generated file called `PS_infer_out.json`, this file is the result from Paragraph Selection and is used by Span Selection.

## Reproduce result