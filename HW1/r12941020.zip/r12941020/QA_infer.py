import json
import torch
import numpy as np
import pandas as pd
from datasets import load_dataset
from tqdm import tqdm
from torch.utils.data import DataLoader
from transformers import (
    AutoConfig,
    AutoModelForQuestionAnswering,
    AutoTokenizer,
    DataCollatorWithPadding,
    default_data_collator,
)
import argparse  
import collections
import logging
import os
from typing import Optional, Tuple

logger = logging.getLogger(__name__)


def postprocess_qa_predictions(examples, features, predictions: Tuple[np.ndarray, np.ndarray], 
                               version_2_with_negative: bool = False, n_best_size: int = 20, 
                               max_answer_length: int = 30, null_score_diff_threshold: float = 0.0, 
                               output_dir: Optional[str] = None, prefix: Optional[str] = None, context = None):
    all_start_logits, all_end_logits = predictions

    example_id_to_index = {k: i for i, k in enumerate(examples["id"])}
    features_per_example = collections.defaultdict(list)
    for i, feature in enumerate(features):
        features_per_example[example_id_to_index[feature["example_id"]]].append(i)

    all_predictions = collections.OrderedDict()

    for example_index, example in enumerate(tqdm(examples)):
        feature_indices = features_per_example[example_index]
        prelim_predictions = []

        for feature_index in feature_indices:
            start_logits = all_start_logits[feature_index]
            end_logits = all_end_logits[feature_index]
            offset_mapping = features[feature_index]["offset_mapping"]
            for start_index in np.argsort(start_logits)[-n_best_size:]:
                for end_index in np.argsort(end_logits)[-n_best_size:]:
                    if end_index < start_index or end_index - start_index + 1 > max_answer_length:
                        continue
                    prelim_predictions.append({
                        "offsets": (offset_mapping[start_index][0], offset_mapping[end_index][1]),
                        "score": start_logits[start_index] + end_logits[end_index],
                    })
        
        predictions = sorted(prelim_predictions, key=lambda x: x["score"], reverse=True)[:n_best_size]
        c = context[example["relevant"]]
        for pred in predictions:
            offsets = pred.pop("offsets")
            pred["text"] = c[offsets[0]:offsets[1]]
        all_predictions[example["id"]] = predictions[0]["text"] if predictions else ""

    if output_dir is not None:
        prediction_file = os.path.join(output_dir, f"{prefix}_predictions.json" if prefix else "predictions.json")
        with open(prediction_file, "w") as writer:
            writer.write(json.dumps(all_predictions, indent=4))

    return all_predictions


def get_args():
    parser = argparse.ArgumentParser(description="Run inference on a QA task")
    parser.add_argument("--context_file", type=str, help="Path to the context file (json format)")
    parser.add_argument("--test_file", type=str, help="Path to the test data file (json format)")
    parser.add_argument("--output_file", type=str, help="Path to save the inference output (csv format)")
    parser.add_argument("--model_path", type=str, help="Path to the pretrained model")
    parser.add_argument("--tokenizer_path", type=str, help="Path to the tokenizer")
    parser.add_argument("--max_seq_len", type=int, default=384, help="Maximum sequence length for tokenization")
    parser.add_argument("--batch_size", type=int, default=8, help="Batch size for inference")
    parser.add_argument("--use_cuda", action="store_true", help="Use CUDA for inference if available")
    return parser.parse_args()


def run_inference():
    args = get_args()

    # Load dataset
    raw_datasets = load_dataset('json', data_files={'test': args.test_file})
    
    # Load context
    with open(args.context_file, 'r', encoding='utf-8') as f:
        context = json.load(f)

    # Load model and tokenizer
    config = AutoConfig.from_pretrained(args.model_path)
    tokenizer = AutoTokenizer.from_pretrained(args.tokenizer_path)
    model = AutoModelForQuestionAnswering.from_pretrained(args.model_path, config=config)

    # Preprocessing
    def prepare_validation_features(examples):
        questions = examples['question']
        mycontext = [context[idx] for idx in examples['relevant']]

        tokenized_examples = tokenizer(
            questions,
            mycontext,
            truncation="only_second",
            max_length=args.max_seq_len,
            stride=128,
            return_overflowing_tokens=True,
            return_offsets_mapping=True,
            padding="max_length",
        )
        sample_mapping = tokenized_examples.pop("overflow_to_sample_mapping")
        tokenized_examples["example_id"] = [examples["id"][sample_mapping[i]] for i in range(len(sample_mapping))]
        return tokenized_examples

    # Process dataset
    test_dataset = raw_datasets['test'].map(
        prepare_validation_features,
        batched=True,
        remove_columns=raw_datasets['test'].column_names,
    )

    data_collator = default_data_collator if args.max_seq_len else DataCollatorWithPadding(tokenizer)
    test_dataloader = DataLoader(test_dataset, collate_fn=data_collator, batch_size=args.batch_size)

    device = torch.device('cuda' if args.use_cuda and torch.cuda.is_available() else 'cpu')
    model.to(device)

    model.eval()
    all_start_logits = []
    all_end_logits = []

    for batch in tqdm(test_dataloader):
        batch = {k: v.to(device) for k, v in batch.items() if k != 'offset_mapping'}  # 排除 offset_mapping
        with torch.no_grad():
            outputs = model(**batch)
            all_start_logits.append(outputs.start_logits.cpu().numpy())
            all_end_logits.append(outputs.end_logits.cpu().numpy())



    start_logits_concat = np.concatenate(all_start_logits, axis=0)
    end_logits_concat = np.concatenate(all_end_logits, axis=0)
    
    outputs_numpy = (start_logits_concat, end_logits_concat)
    predictions = postprocess_qa_predictions(raw_datasets['test'], test_dataset, outputs_numpy, context=context)

    predict_id = [prediction_id for prediction_id in predictions]
    predict_result = [predictions[prediction_id] for prediction_id in predictions]

    df = pd.DataFrame({'id': predict_id, 'answer': predict_result})
    df.to_csv(args.output_file, index=False)
    print(f"Inference completed. Results saved to {args.output_file}")


if __name__ == "__main__":
    run_inference()
