import json
from sklearn.model_selection import train_test_split

# 定義檔案路徑
input_file = './data/data/train.jsonl'
train_output_file = './data/data/train_split.jsonl'
val_output_file = './data/data/validation_split.jsonl'

# 讀取 JSONL 檔案
with open(input_file, 'r', encoding='utf-8') as f:
    data = [json.loads(line) for line in f]

# 切分資料集，80% 作為訓練集，20% 作為驗證集
train_data, val_data = train_test_split(data, test_size=0.2, random_state=42)

# 將訓練集資料寫回新的 JSONL 檔案，使用 ensure_ascii=True 保持 Unicode 格式
with open(train_output_file, 'w', encoding='utf-8') as train_out:
    for entry in train_data:
        json.dump(entry, train_out, ensure_ascii=True)  # ensure_ascii=True 確保格式一致
        train_out.write('\n')

# 將驗證集資料寫回新的 JSONL 檔案，使用 ensure_ascii=True 保持 Unicode 格式
with open(val_output_file, 'w', encoding='utf-8') as val_out:
    for entry in val_data:
        json.dump(entry, val_out, ensure_ascii=True)  # ensure_ascii=True 確保格式一致
        val_out.write('\n')

print(f"訓練集寫入 {train_output_file}，驗證集寫入 {val_output_file}")
