import json
import matplotlib.pyplot as plt

# Function to read data from JSONL file
def load_data_from_jsonl(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            return json.loads(line)  # Assuming the JSONL contains only one line

# 指定 JSONL 檔案路徑
file_path = "./mt5_greedy_3/epoch_results.jsonl"  # 請替換為你的檔案路徑

# 載入資料
data = load_data_from_jsonl(file_path)

# 提取資料用於繪圖
train_losses = data["train_losses"]
#eval_losses = data["eval_losses"]
rouge_1_scores = [score["rouge-1"] for score in data["rouge_scores"]]
rouge_2_scores = [score["rouge-2"] for score in data["rouge_scores"]]
rouge_l_scores = [score["rouge-l"] for score in data["rouge_scores"]]

# 繪製學習曲線和 ROUGE 分數圖
plt.figure(figsize=(14, 5))

# Loss 曲線
plt.subplot(1, 2, 1)
plt.plot(train_losses, label='Train Loss', marker='o')
#plt.plot(eval_losses, label='Eval Loss', marker='o')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.title('Loss')
plt.legend()
plt.grid(True)

# ROUGE 分數曲線
plt.subplot(1, 2, 2)
plt.plot(rouge_1_scores, label='Rouge-1', marker='o')
plt.plot(rouge_2_scores, label='Rouge-2', marker='o')
plt.plot(rouge_l_scores, label='Rouge-L', marker='o')
plt.xlabel('Epoch')
plt.ylabel('ROUGE Score')
plt.title('ROUGE Score')
plt.legend()
plt.grid(True)

# 顯示圖表
plt.show()

