

python test.py 
    --model_name_or_path <model_name_or_path> \
    --test_file ${1} \
    --output_file ${2} \
    --num_beams 5 \
    --max_target_length 64 \
    --use_cuda \