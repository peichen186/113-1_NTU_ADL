# ADL-HW2 
光電所 宋姵蓁 R12941020

## Code Reference
 - https://github.com/huggingface/transformers/blob/main/examples/pytorch/summarization/run_summarization_no_trainer.py

## Environment Setting
 - Python = 3.8.10
 - Use `pip install -r requirements.txt` to install packages.
 - Install matplotlib if plotting is needed.

## Installation
 - git clone https://github.com/deankuo/ADL24-HW2.git
 - cd ADL24-HW2
 - pip install -e tw_rouge

## Steps to spilt training data
 - Spilting code is `split.py`.
 - It will spilt training data to training data(80%) and validation data(20%) for training model.
 - Run
    python spilt.py \
    --input_file <input_file> \
    --train_output_file <train_output_file> \
    --val_output_file <val_output_file> \

## Steps to run trainning
 - Trainning code is `train.py`.
 - Adjust the hyperparameters.
 - Run
    python train.py \
    --model_name_or_path google/mt5-samll \
    --output_dir <output_dir> \
    --text_column maintext \
    --summary_column title \
    --train_file <train_file> \
    --validation_file <validation_file> \
    --per_device_train_batch_size 8 \
    --per_device_eval_batch_size 8 \
    --gradient_accumulation_steps 4 \
    --learning_rate 3e-3 \
    --num_train_epochs 10 \
    --num_beams 1 \
    --num_warmup_steps 500 \
    --max_source_length 256 \
    --max_target_length 64 \
    --top_p 1.0 \
    --top_k 0 \
    --do_sample True \
    --temperature 1.0 \
    --source_prefix "summarize: \

## Steps to run inference
 - Inference code is `test.py`.
 - Run `bash download.sh` first to download trained models.
 - Then run `bash run.sh {path_to_input_jsonl} {path_to_output_jsonl} ` and replace the paths.

## Reproduce result

## Steps to run eval
 -usage: eval.py [-h] [-r REFERENCE] [-s SUBMISSION]

 -optional arguments:
   -h, --help            show this help message and exit
   -r REFERENCE, --reference REFERENCE
   -s SUBMISSION, --submission SUBMISSION