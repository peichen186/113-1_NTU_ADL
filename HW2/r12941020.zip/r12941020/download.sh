#!bin/bash
gdown -O model.zip 1sBFiZbQVVShyPQCWYpW6fAgMzBLFz1lI
gdown -O data.zip 11lOeUnEACVaeeGvSTNxsv048M9SIfGgf

unzip model.zip
unzip data.zip

rm model.zip
rm data.zip