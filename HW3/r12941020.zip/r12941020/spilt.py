import json
import random

# 設定檔案路徑
input_file = './data/train.json'  # 原始訓練資料檔案路徑
output_file = './data/train_70.json'  # 切割後的訓練資料儲存路徑

# 設定要保留的資料比例
retain_ratio = 0.7

# 讀取資料
with open(input_file, 'r', encoding='utf-8') as f:
    data = json.load(f)

# 計算要保留的資料筆數
retain_count = int(len(data) * retain_ratio)

# 隨機打亂並切割資料
random.shuffle(data)
data_subset = data[:retain_count]

# 儲存切割後的資料
with open(output_file, 'w', encoding='utf-8') as f:
    json.dump(data_subset, f, ensure_ascii=False, indent=4)

print(f"資料已成功切割並儲存到 {output_file}，包含 {retain_count} 筆資料。")
