
import json
import argparse
from tqdm import tqdm
from utils import get_prompt, get_bnb_config
from peft import LoraConfig, PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--base_model', type=str, default="zake7749/gemma-2-2b-it-chinese-kyara-dpo", help="Base model name or path")
    parser.add_argument('--peft_model', type=str, default="adapter_checkpoint", help="Path to fine-tuned model adapter")
    parser.add_argument('--input_json', type=str, default="data/public_test.json", help="Input JSON file with instructions")
    parser.add_argument('--output_json', type=str, default="output.json", help="Output JSON file for results")
    args = parser.parse_args()

    # Load configurations
    quant_config = get_bnb_config()
    lora_config = LoraConfig.from_pretrained(args.peft_model)

    # Initialize model and tokenizer
    base_model = AutoModelForCausalLM.from_pretrained(args.base_model, quantization_config=quant_config, device_map='cuda:0')
    tokenizer = AutoTokenizer.from_pretrained(args.base_model)
    model = PeftModel.from_pretrained(base_model, args.peft_model)

    # Load input data
    with open(args.input_json, "r") as infile:
        instructions = json.load(infile)

    results = []
    for item in tqdm(instructions):
        prompt = get_prompt(item['instruction'])
        inputs = tokenizer(prompt, return_tensors="pt").to("cuda")
        outputs = model.generate(**inputs, max_new_tokens=128)
        response = tokenizer.decode(outputs[0], skip_special_tokens=True)[len(prompt):].strip()
        
        results.append({'id': item['id'], 'output': response})

    # Save results
    with open(args.output_json, "w") as outfile:
        json.dump(results, outfile, indent=4, ensure_ascii=False)

if __name__ == '__main__':
    main()