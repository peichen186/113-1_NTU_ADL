from transformers import BitsAndBytesConfig
import torch


def get_prompt(instruction: str) -> str:
    '''Format the instruction as a prompt for LLM.'''
    return f"你是精通文言文的大師，負責將現代中文轉換成精準的文言文，或反之亦然。根據以下要求提供簡潔且準確的回答。用戶的指令如下。USER：{instruction} ASSISTANT："


def get_bnb_config() -> BitsAndBytesConfig:
    '''Get the BitsAndBytesConfig.'''
    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        load_in_8bit=False,
        llm_int8_threshold=6.0,
        llm_int8_has_fp16_weight=False,
        bnb_4bit_compute_dtype=torch.bfloat16,
        bnb_4bit_use_double_quant=True,
        bnb_4bit_quant_type='nf4',
    )
    return bnb_config

def get_few_shot_prompt(instruction, idx, data, shotcnt):
    if shotcnt == 0:
        return get_prompt(instruction)
    else:
        example = '以下為幾個翻譯的正確例子\n'
        for i in range(shotcnt):
            example += f'USER:{data[idx-i]["instruction"]} ASSISTANT:{data[idx-i]["output"]} \n'

        example += '\n以下為你需要翻譯的句子，請根據前面提供的正確結果進行翻譯\n'
        prompt = f"你是精通文言文的大師，負責將現代中文轉換成精準的文言文，或反之亦然。根據以下要求提供簡潔且準確的回答。用戶的指令如下。{example} USER：{instruction} ASSISTANT："
        return prompt