#!bin/bash

mkdir adapter_checkpoint
gdown -O adapter_checkpoint/adapter_config.json 1QSJR3LndMBf_iMyW9hCwbcPXAOy2gWlw
gdown -O adapter_checkpoint/adapter_model.safetensors 1KmB05NctxxSqqIbtHI7BT4lU69pkzA6K
