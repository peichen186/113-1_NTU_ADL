import os
import json
import torch
import matplotlib.pyplot as plt
from transformers import AutoModelForCausalLM, AutoTokenizer
from ppl import perplexity  # Import perplexity function from ppl.py

# Define paths
checkpoint_dir = "./output/"  # Replace with your checkpoint directory path
validation_file = "./data/public_test.json"  # Replace with your public_test.json path
loss_file = "./output/trainer_state.json"  # Replace with your trainer_state.json path

# Load validation data for perplexity calculation
with open(validation_file, "r", encoding="utf-8") as f:
    validation_data = json.load(f)

# Load loss data from trainer_state.json
with open(loss_file, "r") as f:
    loss_data = json.load(f)

# Process checkpoints for perplexity
checkpoints = sorted(
    [os.path.join(checkpoint_dir, d) for d in os.listdir(checkpoint_dir) if d.startswith("checkpoint-")],
    key=lambda x: int(x.split("-")[-1])
)

# Initialize lists for perplexity
perplexities = []
perplexity_steps = []

# Model name for initializing tokenizer and model
initial_model_name = "zake7749/gemma-2-2b-it-chinese-kyara-dpo"

# Calculate perplexity for each checkpoint
for checkpoint in checkpoints:
    step = int(checkpoint.split("-")[-1])  # Get step from checkpoint
    perplexity_steps.append(step)

    # Load model and tokenizer
    model = AutoModelForCausalLM.from_pretrained(checkpoint, config=initial_model_name)
    tokenizer = AutoTokenizer.from_pretrained(initial_model_name)

    # Calculate mean perplexity
    ppl_result = perplexity(model, tokenizer, validation_data)
    mean_ppl = ppl_result["mean_perplexity"]
    perplexities.append(mean_ppl)
    print(f"Checkpoint {step}: Mean Perplexity = {mean_ppl}")

# Extract loss data from trainer_state.json
loss_steps = []
losses = []

for entry in loss_data["log_history"]:
    if "loss" in entry:
        loss_steps.append(entry["step"])
        losses.append(entry["loss"])

# Plot both perplexity and loss on the same figure
plt.figure(figsize=(10, 6))
plt.plot(perplexity_steps, perplexities, marker='o', label="Mean Perplexity", color="blue")
plt.plot(loss_steps, losses, label="Training Loss", color="red", linewidth=1.5)
plt.xlabel("Steps")
plt.ylabel("Values")
plt.title("Mean Perplexity and Training Loss across Checkpoints")
plt.legend()
plt.grid(True)
plt.show()