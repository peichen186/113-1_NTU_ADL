# ADL-HW3 
光電所 宋姵蓁 R12941020

## Code Reference
 - https://github.com/artidoro/qlora/blob/main/qlora.py

## Environment Setting
 - Python = 3.10
 - Use `pip install -r requirements.txt` to install packages.
 - Install matplotlib if plotting is needed.

## Steps to spilt training data
 - Spilting code is `split.py`.
 - It will remain part of training data for training model.
 - Run
    python spilt.py \
    --input_file <input_file> \
    --output_file <output_file> \
    --retain_ratio 0.7 \

## Steps to run trainning
 - Trainning code is `train.py`.
 - Adjust the hyperparameters.
 - Run
    python train.py \
    --model_name_or_path zake7749/gemma-2-2b-it-chinese-kyara-dpo \
    --output_dir ./output \
    --dataset ./data/train_70.json \
    --dataset_format self-defined \
    --bits 4 \
    --bf16 \
    --do_train \
    --max_steps 1000 \
    --save_steps 100 \
    --per_device_train_batch_size 4 \
    --learning_rate 1e-4 \
    --max_train_epochs 5 \
    --evaluation_strategy "steps" \
    --eval_steps "100" \
    --gradient_accumulation_steps 1 \
    --overwrite_output_dir \
    --source_max_len 1024 \
    --target_max_len 256 \

## Steps to run inference
 - Inference code is `infer.py`.
 - Run `bash download.sh` first to download trained models.
 - Then run `bash run.sh {base_model} {peft_model} {input_json} {output_json} ` and replace the paths.

## Reproduce result

## Steps to run ppl
 - Trainning code is `ppl.py`.
 - Run
    python ppl.py \
    --base_model_path zake7749/gemma-2-2b-it-chinese-kyara-dpo \
    --peft_path /path/to/adapter_checkpoint/under/your/folder \
    --test_data_path /path/to/input/data \